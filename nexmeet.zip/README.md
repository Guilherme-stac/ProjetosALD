# NexMeet

MVP de videoconferência em tempo real (WebRTC + Socket.IO) com sistema de
login por conta (nome, e-mail e senha) — chamadas de vídeo, áudio, chat e
compartilhamento de tela, tudo direto do navegador.

## Como rodar

```bash
npm install
npm start
```

Acesse `http://localhost:3000`. Na primeira visita você será levado para a
tela de login/criação de conta — depois disso, criar ou entrar em salas
funciona como antes.

Recomenda-se copiar `.env.example` para `.env` e definir pelo menos
`SESSION_SECRET` antes de publicar em produção (veja os comentários no
próprio arquivo).

## O que foi feito nesta versão

- **Sistema de login completo**: cadastro (`/register.html`) e login
  (`/login.html`) com sessão de servidor (cookie `httpOnly`), senhas com
  hash `bcrypt` e usuários salvos em `data/users.json` (arquivo criado
  automaticamente, sem precisar de banco de dados externo).
- **Rotas protegidas**: a página inicial, as salas e a API de criação/consulta
  de salas agora exigem login; as conexões Socket.IO de sinalização também
  verificam a sessão antes de aceitar qualquer evento.
- **Rate limiting** dedicado para login/cadastro, para dificultar força bruta.
- **Correções de bugs**:
  - Ícones de câmera ligada/desligada que usavam o mesmo emoji nos controles
    da sala e na lista de participantes.
  - Content-Security-Policy do Helmet não liberava as fontes do Google Fonts
    usadas pelo CSS (`fonts.googleapis.com`/`fonts.gstatic.com`), o que podia
    bloquear o carregamento das fontes no navegador.
  - Função `escapeHtml` duplicada entre `room.js` e `participants.js`.
  - `package-lock.json` desatualizado em relação às novas dependências.
- **Visual**: chip de usuário com menu de logout na navbar, páginas de
  login/cadastro no mesmo estilo (glassmorphism, gradiente roxo→azul) do
  restante do site, textura sutil de ruído no fundo e variação de cor nos
  ícones dos cards de recursos para dar mais profundidade visual.

## Estrutura

```
server.js              servidor Express + Socket.IO + autenticação
src/roomManager.js      salas em memória
src/socketRateLimiter.js rate limit por socket
src/userStore.js         usuários persistidos em data/users.json (novo)
public/                  frontend (login, cadastro, home, sala)
```
