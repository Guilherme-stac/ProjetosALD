// src/socketRateLimiter.js
// Rate limiting simples por socket, em memória, sem dependências externas.
// Cada evento tem seu próprio limite (janela deslizante em ms).
// Objetivo: impedir flood de chat, join-room e signal (DoS barato).

class SocketRateLimiter {
  constructor() {
    // socketId -> eventName -> array de timestamps
    this.hits = new Map();
  }

  // Retorna true se a ação é permitida; false se estourou o limite.
  check(socketId, eventName, maxHits, windowMs) {
    const now = Date.now();
    let perSocket = this.hits.get(socketId);
    if (!perSocket) {
      perSocket = new Map();
      this.hits.set(socketId, perSocket);
    }

    let timestamps = perSocket.get(eventName) || [];
    // Descarta timestamps fora da janela
    timestamps = timestamps.filter((t) => now - t < windowMs);

    if (timestamps.length >= maxHits) {
      perSocket.set(eventName, timestamps);
      return false;
    }

    timestamps.push(now);
    perSocket.set(eventName, timestamps);
    return true;
  }

  // Limpa os contadores de um socket ao desconectar (evita vazamento de memória)
  clear(socketId) {
    this.hits.delete(socketId);
  }
}

module.exports = { SocketRateLimiter };
