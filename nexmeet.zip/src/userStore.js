// src/userStore.js
// Armazenamento simples de usuários em arquivo JSON (data/users.json).
// Suficiente para um MVP sem infraestrutura de banco de dados externa.
// Em produção com múltiplas instâncias, isso deveria virar um banco real
// (Postgres, SQLite compartilhado, etc.) — mas a interface abaixo já
// isola essa decisão do resto do app.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DATA_FILE = path.join(DATA_DIR, 'users.json');

function ensureStore() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]', 'utf8');
}

function loadUsers() {
  ensureStore();
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('[userStore] Falha ao ler data/users.json, iniciando vazio:', err.message);
    return [];
  }
}

function saveUsers(users) {
  ensureStore();
  fs.writeFileSync(DATA_FILE, JSON.stringify(users, null, 2), 'utf8');
}

function normalizeEmail(email) {
  return String(email || '').trim().toLowerCase();
}

function findByEmail(email) {
  const normalized = normalizeEmail(email);
  return loadUsers().find((u) => u.email === normalized) || null;
}

function findById(id) {
  return loadUsers().find((u) => u.id === id) || null;
}

// Cria um novo usuário. Espera que passwordHash já venha pronto (bcrypt).
function createUser({ name, email, passwordHash }) {
  const users = loadUsers();
  const user = {
    id: crypto.randomUUID(),
    name: String(name).trim().slice(0, 60),
    email: normalizeEmail(email),
    passwordHash,
    createdAt: Date.now()
  };
  users.push(user);
  saveUsers(users);
  return user;
}

// Retorna apenas os campos seguros para expor ao cliente/sessão.
function toPublicUser(user) {
  if (!user) return null;
  return { id: user.id, name: user.name, email: user.email };
}

module.exports = { findByEmail, findById, createUser, toPublicUser, normalizeEmail };
