// src/roomManager.js
// Responsável por gerenciar salas e participantes em memória.
// Em produção, isso poderia ser substituído por Redis para suportar múltiplas instâncias do servidor.

const crypto = require('crypto');

class RoomManager {
  constructor() {
    // roomId -> Map(socketId -> { userName, audio, video })
    this.rooms = new Map();
  }

  // Gera um ID de sala aleatório e difícil de adivinhar (ex: "a1b2-c3d4-e5f6")
  generateRoomId() {
    const part = () => crypto.randomBytes(2).toString('hex');
    return `${part()}-${part()}-${part()}`;
  }

  // Cria uma nova sala vazia e retorna seu ID único.
  // Se passwordHash for informado, a sala fica trancada: só entra quem
  // apresentar o hash correto em join-room. O host recebe o hash em texto
  // puro apenas no momento da criação (nunca fica em log nem é reexibido).
  createRoom(passwordHash = null) {
    let roomId = this.generateRoomId();
    while (this.rooms.has(roomId)) {
      roomId = this.generateRoomId();
    }
    this.rooms.set(roomId, new Map());
    if (passwordHash) {
      this.roomPasswords = this.roomPasswords || new Map();
      this.roomPasswords.set(roomId, passwordHash);
    }
    return roomId;
  }

  roomExists(roomId) {
    return this.rooms.has(roomId);
  }

  isLocked(roomId) {
    return !!(this.roomPasswords && this.roomPasswords.has(roomId));
  }

  checkPassword(roomId, passwordHash) {
    if (!this.isLocked(roomId)) return true;
    return this.roomPasswords.get(roomId) === passwordHash;
  }

  addParticipant(roomId, socketId, info) {
    if (!this.rooms.has(roomId)) {
      this.rooms.set(roomId, new Map());
    }
    this.rooms.get(roomId).set(socketId, info);
  }

  updateParticipant(roomId, socketId, patch) {
    const room = this.rooms.get(roomId);
    if (!room || !room.has(socketId)) return;
    room.set(socketId, { ...room.get(socketId), ...patch });
  }

  removeParticipant(roomId, socketId) {
    const room = this.rooms.get(roomId);
    if (!room) return;
    room.delete(socketId);
    // Limpa salas vazias para não acumular memória indefinidamente
    if (room.size === 0) {
      this.rooms.delete(roomId);
      if (this.roomPasswords) this.roomPasswords.delete(roomId);
    }
  }

  getParticipants(roomId) {
    const room = this.rooms.get(roomId);
    if (!room) return [];
    return Array.from(room.entries()).map(([socketId, info]) => ({
      socketId,
      ...info
    }));
  }

  getParticipantCount(roomId) {
    const room = this.rooms.get(roomId);
    return room ? room.size : 0;
  }
}

module.exports = { RoomManager };
