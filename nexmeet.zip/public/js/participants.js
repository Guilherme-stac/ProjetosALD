// participants.js - Renderiza o painel lateral com a lista de participantes

class ParticipantsController {
  constructor({ mySocketId }) {
    this.mySocketId = mySocketId;
    this.listEl = document.getElementById('participants-list');
    this.countLabelEl = document.getElementById('participant-count-label');
    this.countNumEl = document.getElementById('participants-count-num');
    // participantId -> { userName, audio, video, speaking }
    this.participants = new Map();
  }

  upsert(id, patch) {
    const current = this.participants.get(id) || { userName: 'Convidado', audio: true, video: true, speaking: false };
    this.participants.set(id, { ...current, ...patch });
    this.render();
  }

  remove(id) {
    this.participants.delete(id);
    this.render();
  }

  getInitials(name) {
    return (name || '?').trim().charAt(0).toUpperCase();
  }

  render() {
    const total = this.participants.size;
    this.countLabelEl.textContent = `${total} participante${total !== 1 ? 's' : ''}`;
    this.countNumEl.textContent = total;

    this.listEl.innerHTML = '';
    for (const [id, info] of this.participants) {
      const isYou = id === this.mySocketId;
      const row = document.createElement('div');
      row.className = `participant-row ${info.speaking ? 'speaking' : ''}`;

      row.innerHTML = `
        <div class="p-avatar">${this.getInitials(info.userName)}</div>
        <div class="p-info">
          <div class="p-name">${escapeHtml(info.userName)} ${isYou ? '<span class="you-tag">(você)</span>' : ''}</div>
        </div>
        <div class="p-icons">
          <span class="${info.audio ? '' : 'off'}">${info.audio ? '🎤' : '🔇'}</span>
          <span class="${info.video ? '' : 'off'}">${info.video ? '📷' : '🚫'}</span>
        </div>
      `;
      this.listEl.appendChild(row);
    }
  }
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
