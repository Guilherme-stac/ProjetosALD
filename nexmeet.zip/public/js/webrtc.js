// webrtc.js - Gerencia as conexões WebRTC ponto-a-ponto (topologia "mesh":
// cada participante se conecta diretamente a todos os outros).
// O servidor Socket.IO é usado apenas para troca de sinalização (SDP/ICE);
// o áudio, vídeo e tela trafegam diretamente entre os navegadores.

class WebRTCManager {
  /**
   * @param {object} opts
   * @param {SocketIOClient} opts.socket - conexão socket.io já conectada
   * @param {(peerId:string, stream:MediaStream) => void} opts.onRemoteStream - novo stream remoto disponível
   * @param {(peerId:string) => void} opts.onPeerClosed - conexão com um peer foi encerrada
   */
  constructor({ socket, onRemoteStream, onPeerClosed }) {
    this.socket = socket;
    this.onRemoteStream = onRemoteStream;
    this.onPeerClosed = onPeerClosed;

    this.localStream = null;          // stream de câmera/mic local
    this.peers = new Map();           // peerId -> RTCPeerConnection
    this.senders = new Map();         // peerId -> { videoSender, audioSender }

    // Servidores STUN públicos para descoberta de endereço (NAT traversal).
    // Para redes mais restritivas (CGNAT, firewalls corporativos), seria
    // necessário adicionar também um servidor TURN em produção.
    this.iceServers = [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' }
    ];

    this._bindSocketEvents();
  }

  setLocalStream(stream) {
    this.localStream = stream;
  }

  _bindSocketEvents() {
    this.socket.on('signal', async ({ from, signal }) => {
      let pc = this.peers.get(from);

      if (signal.type === 'offer') {
        if (!pc) pc = this._createPeerConnection(from);
        await pc.setRemoteDescription(new RTCSessionDescription(signal));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        this.socket.emit('signal', { to: from, signal: pc.localDescription });
      } else if (signal.type === 'answer') {
        if (pc) await pc.setRemoteDescription(new RTCSessionDescription(signal));
      } else if (signal.candidate) {
        if (pc) {
          try { await pc.addIceCandidate(new RTCIceCandidate(signal)); }
          catch (err) { console.warn('Erro ao adicionar ICE candidate:', err); }
        }
      }
    });
  }

  // Chamado pelo iniciador da conexão (quem acabou de entrar na sala)
  async connectToPeer(peerId) {
    if (this.peers.has(peerId)) return;
    const pc = this._createPeerConnection(peerId);
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    this.socket.emit('signal', { to: peerId, signal: pc.localDescription });
  }

  _createPeerConnection(peerId) {
    const pc = new RTCPeerConnection({ iceServers: this.iceServers });
    this.peers.set(peerId, pc);

    // Adiciona as tracks locais (áudio/vídeo) à conexão
    const senderInfo = {};
    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => {
        const sender = pc.addTrack(track, this.localStream);
        if (track.kind === 'video') senderInfo.videoSender = sender;
        if (track.kind === 'audio') senderInfo.audioSender = sender;
      });
    }
    this.senders.set(peerId, senderInfo);

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        this.socket.emit('signal', { to: peerId, signal: event.candidate });
      }
    };

    pc.ontrack = (event) => {
      this.onRemoteStream?.(peerId, event.streams[0]);
    };

    pc.onconnectionstatechange = () => {
      if (['disconnected', 'failed', 'closed'].includes(pc.connectionState)) {
        this._closePeer(peerId);
      }
    };

    return pc;
  }

  _closePeer(peerId) {
    const pc = this.peers.get(peerId);
    if (pc) {
      pc.close();
      this.peers.delete(peerId);
      this.senders.delete(peerId);
      this.onPeerClosed?.(peerId);
    }
  }

  removePeer(peerId) {
    this._closePeer(peerId);
  }

  // Substitui a track de vídeo enviada a TODOS os peers (usado para compartilhar tela
  // sem precisar renegociar a conexão inteira - RTCRtpSender.replaceTrack).
  async replaceVideoTrackForAll(newTrack) {
    for (const [, senderInfo] of this.senders) {
      if (senderInfo.videoSender) {
        await senderInfo.videoSender.replaceTrack(newTrack);
      }
    }
  }

  closeAll() {
    for (const peerId of Array.from(this.peers.keys())) {
      this._closePeer(peerId);
    }
  }
}
