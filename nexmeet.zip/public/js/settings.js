// settings.js - Utilitários para seleção de dispositivos (câmera/mic/alto-falante)
// e teste de nível de microfone via Web Audio API.

// Preenche um <select> com os dispositivos de um determinado tipo (videoinput/audioinput/audiooutput)
async function populateDeviceSelect(selectEl, kind, savedDeviceId) {
  const devices = await navigator.mediaDevices.enumerateDevices();
  const filtered = devices.filter((d) => d.kind === kind);

  selectEl.innerHTML = '';
  filtered.forEach((device, idx) => {
    const opt = document.createElement('option');
    opt.value = device.deviceId;
    opt.textContent = device.label || `${labelForKind(kind)} ${idx + 1}`;
    selectEl.appendChild(opt);
  });

  if (savedDeviceId && filtered.some((d) => d.deviceId === savedDeviceId)) {
    selectEl.value = savedDeviceId;
  }

  return filtered;
}

function labelForKind(kind) {
  if (kind === 'videoinput') return 'Câmera';
  if (kind === 'audioinput') return 'Microfone';
  if (kind === 'audiooutput') return 'Alto-falante';
  return 'Dispositivo';
}

// Mede o nível de áudio de um MediaStream em tempo real (para o medidor de teste de mic)
class MicLevelTester {
  constructor(stream, onLevel) {
    this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    this.analyser = this.audioCtx.createAnalyser();
    this.analyser.fftSize = 512;
    this.source = this.audioCtx.createMediaStreamSource(stream);
    this.source.connect(this.analyser);
    this.data = new Uint8Array(this.analyser.frequencyBinCount);
    this.onLevel = onLevel;
    this.running = false;
  }

  start() {
    this.running = true;
    const loop = () => {
      if (!this.running) return;
      this.analyser.getByteFrequencyData(this.data);
      const avg = this.data.reduce((a, b) => a + b, 0) / this.data.length;
      this.onLevel(Math.min(100, (avg / 130) * 100));
      requestAnimationFrame(loop);
    };
    loop();
  }

  stop() {
    this.running = false;
    try { this.source.disconnect(); } catch {}
    try { this.audioCtx.close(); } catch {}
  }
}
