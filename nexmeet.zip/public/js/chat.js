// chat.js - Renderização e envio de mensagens do chat da sala

class ChatController {
  constructor({ mySocketId, onUnread }) {
    this.mySocketId = mySocketId;
    this.onUnread = onUnread;
    this.messagesEl = document.getElementById('chat-messages');
    this.formEl = document.getElementById('chat-form');
    this.inputEl = document.getElementById('chat-input');
    this.panelEl = document.getElementById('chat-panel');

    this.formEl.addEventListener('submit', (e) => {
      e.preventDefault();
      const text = this.inputEl.value.trim();
      if (!text) return;
      this.onSend?.(text);
      this.inputEl.value = '';
    });
  }

  isOpen() {
    return !this.panelEl.classList.contains('hidden-panel');
  }

  addMessage({ socketId, userName, text, timestamp }) {
    const isOwn = socketId === this.mySocketId;
    const wrapper = document.createElement('div');
    wrapper.className = `chat-msg fade-in ${isOwn ? 'own' : ''}`;

    const time = new Date(timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    const meta = document.createElement('div');
    meta.className = 'msg-meta';
    meta.textContent = `${isOwn ? 'Você' : userName} · ${time}`;

    const bubble = document.createElement('div');
    bubble.className = 'msg-bubble';
    bubble.textContent = text; // textContent evita XSS (nunca usar innerHTML aqui)

    wrapper.appendChild(meta);
    wrapper.appendChild(bubble);
    this.messagesEl.appendChild(wrapper);
    this.messagesEl.scrollTop = this.messagesEl.scrollHeight;

    if (!isOwn && !this.isOpen()) {
      this.onUnread?.();
    }
  }
}
