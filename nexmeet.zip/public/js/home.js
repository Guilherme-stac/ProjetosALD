// home.js - Lógica da página inicial: criar sala ou entrar com código/link

// ---------- Usuário logado (navbar) ----------
const userChipBtn = document.getElementById('user-chip-btn');
const userChipMenu = document.getElementById('user-chip-menu');
const userChipAvatar = document.getElementById('user-chip-avatar');
const userChipName = document.getElementById('user-chip-name');
const userChipEmail = document.getElementById('user-chip-email');
const btnLogout = document.getElementById('btn-logout');

(async function loadCurrentUser() {
  try {
    const res = await fetch('/api/auth/me');
    const data = await res.json();
    if (!data.user) {
      window.location.href = '/login.html';
      return;
    }
    userChipName.textContent = data.user.name;
    userChipEmail.textContent = data.user.email;
    userChipAvatar.textContent = (data.user.name || '?').trim().charAt(0).toUpperCase();
  } catch {
    userChipName.textContent = 'Conta';
  }
})();

userChipBtn?.addEventListener('click', () => {
  const willOpen = userChipMenu.classList.contains('hidden');
  userChipMenu.classList.toggle('hidden', !willOpen);
  userChipBtn.setAttribute('aria-expanded', String(willOpen));
});

document.addEventListener('click', (e) => {
  if (!userChipMenu || userChipMenu.classList.contains('hidden')) return;
  if (!e.target.closest('.user-chip-wrap')) {
    userChipMenu.classList.add('hidden');
    userChipBtn?.setAttribute('aria-expanded', 'false');
  }
});

btnLogout?.addEventListener('click', async () => {
  try {
    await fetch('/api/auth/logout', { method: 'POST' });
  } finally {
    window.location.href = '/login.html';
  }
});

const btnCreateRoom = document.getElementById('btn-create-room');
const btnJoinToggle = document.getElementById('btn-join-toggle');
const joinForm = document.getElementById('join-form');
const joinCodeInput = document.getElementById('join-code-input');

const createModal = document.getElementById('create-modal');
const modalRoomCode = document.getElementById('modal-room-code');
const modalRoomLink = document.getElementById('modal-room-link');
const btnCopyLink = document.getElementById('btn-copy-link');
const btnCancelModal = document.getElementById('btn-cancel-modal');
const btnEnterRoom = document.getElementById('btn-enter-room');
const protectRoomCheck = document.getElementById('protect-room-check');
const protectRoomPassword = document.getElementById('protect-room-password');

let createdRoomId = null;

protectRoomCheck.addEventListener('change', () => {
  protectRoomPassword.classList.toggle('hidden', !protectRoomCheck.checked);
  if (protectRoomCheck.checked) protectRoomPassword.focus();
});

// Alterna a exibição do campo "entrar com código"
btnJoinToggle.addEventListener('click', () => {
  const isHidden = joinForm.style.display === 'none';
  joinForm.style.display = isHidden ? 'flex' : 'none';
  if (isHidden) {
    joinCodeInput.focus();
    joinForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
});

// O CTA da navbar reaproveita o mesmo fluxo (evita duplicar lógica)
document.getElementById('nav-join-btn')?.addEventListener('click', () => btnJoinToggle.click());

// Extrai o ID da sala de um código puro OU de um link completo
function extractRoomId(value) {
  const trimmed = value.trim();
  try {
    const url = new URL(trimmed);
    const parts = url.pathname.split('/').filter(Boolean);
    return parts[parts.length - 1] || trimmed;
  } catch {
    return trimmed; // não é uma URL válida, assume que já é o código
  }
}

joinForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const value = joinCodeInput.value;
  if (!value.trim()) return;
  const roomId = extractRoomId(value);
  window.location.href = `/room/${encodeURIComponent(roomId)}`;
});

// Criar sala: chama a API do backend, que gera um ID único e difícil de adivinhar
btnCreateRoom.addEventListener('click', async () => {
  btnCreateRoom.disabled = true;
  btnCreateRoom.textContent = 'Criando...';
  try {
    const usePassword = protectRoomCheck.checked && protectRoomPassword.value.trim();
    const res = await fetch('/api/rooms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(usePassword ? { password: protectRoomPassword.value.trim() } : {})
    });
    const data = await res.json();
    createdRoomId = data.roomId;

    modalRoomCode.textContent = createdRoomId;
    modalRoomLink.value = `${window.location.origin}/room/${createdRoomId}`;
    if (data.locked) {
      showToast('Sala criada com senha. Compartilhe a senha separadamente do link.');
    }
    createModal.classList.remove('hidden');
  } catch (err) {
    showToast('Não foi possível criar a sala. Tente novamente.');
  } finally {
    btnCreateRoom.disabled = false;
    btnCreateRoom.textContent = '➕ Criar sala';
  }
});

btnCopyLink.addEventListener('click', async () => {
  modalRoomLink.select();
  try {
    await navigator.clipboard.writeText(modalRoomLink.value);
  } catch {
    document.execCommand('copy');
  }
  showToast('Link copiado!');
  btnCopyLink.textContent = '✅';
  btnCopyLink.classList.add('copied');
  setTimeout(() => {
    btnCopyLink.textContent = '📋';
    btnCopyLink.classList.remove('copied');
  }, 1500);
});

btnCancelModal.addEventListener('click', () => {
  createModal.classList.add('hidden');
});

btnEnterRoom.addEventListener('click', () => {
  if (createdRoomId) window.location.href = `/room/${createdRoomId}`;
});
