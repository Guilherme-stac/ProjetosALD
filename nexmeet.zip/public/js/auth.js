// auth.js - Lógica dos formulários de login e criação de conta

function getRedirectTarget() {
  const params = new URLSearchParams(window.location.search);
  const target = params.get('redirect');
  // Só aceita caminhos internos (evita redirecionar para outro domínio)
  if (target && target.startsWith('/') && !target.startsWith('//')) return target;
  return '/';
}

function showFormError(el, message) {
  el.textContent = message;
  el.classList.remove('hidden');
}

function hideFormError(el) {
  el.classList.add('hidden');
  el.textContent = '';
}

async function submitAuth(url, payload) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  let data = {};
  try { data = await res.json(); } catch { /* corpo vazio */ }
  if (!res.ok) throw new Error(data.error || 'Algo deu errado. Tente novamente.');
  return data;
}

// ---------- Formulário de login ----------
const loginForm = document.getElementById('login-form');
if (loginForm) {
  const errorEl = document.getElementById('login-error');
  const submitBtn = document.getElementById('login-submit');

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    hideFormError(errorEl);
    submitBtn.disabled = true;
    submitBtn.textContent = 'Entrando...';
    try {
      await submitAuth('/api/auth/login', {
        email: document.getElementById('login-email').value.trim(),
        password: document.getElementById('login-password').value
      });
      window.location.href = getRedirectTarget();
    } catch (err) {
      showFormError(errorEl, err.message);
      submitBtn.disabled = false;
      submitBtn.textContent = 'Entrar';
    }
  });
}

// ---------- Formulário de registro ----------
const registerForm = document.getElementById('register-form');
if (registerForm) {
  const errorEl = document.getElementById('register-error');
  const submitBtn = document.getElementById('register-submit');

  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    hideFormError(errorEl);
    submitBtn.disabled = true;
    submitBtn.textContent = 'Criando conta...';
    try {
      await submitAuth('/api/auth/register', {
        name: document.getElementById('register-name').value.trim(),
        email: document.getElementById('register-email').value.trim(),
        password: document.getElementById('register-password').value
      });
      window.location.href = getRedirectTarget();
    } catch (err) {
      showFormError(errorEl, err.message);
      submitBtn.disabled = false;
      submitBtn.textContent = 'Criar conta';
    }
  });
}
