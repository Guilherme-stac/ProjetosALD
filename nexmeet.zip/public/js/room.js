// room.js - Controlador principal da sala: liga o lobby (pré-entrada), a sinalização
// via Socket.IO, o gerenciador WebRTC, o chat, a lista de participantes e os controles.

(function () {
  const roomId = window.location.pathname.split('/').filter(Boolean).pop();

  // ---------- Elementos: Lobby ----------
  const lobbyView = document.getElementById('lobby-view');
  const lobbyVideo = document.getElementById('lobby-video');
  const lobbyAvatarFallback = document.getElementById('lobby-avatar-fallback');
  const lobbyRoomIdEl = document.getElementById('lobby-room-id');
  const lobbyUsername = document.getElementById('lobby-username');
  const lobbyCameraSelect = document.getElementById('lobby-camera-select');
  const lobbyMicSelect = document.getElementById('lobby-mic-select');
  const lobbyToggleMic = document.getElementById('lobby-toggle-mic');
  const lobbyToggleCam = document.getElementById('lobby-toggle-cam');
  const lobbyJoinBtn = document.getElementById('lobby-join-btn');

  // ---------- Elementos: Sala de chamada ----------
  const callView = document.getElementById('call-view');
  const callRoomName = document.getElementById('call-room-name');
  const videoStage = document.getElementById('video-stage');
  const videoGrid = document.getElementById('video-grid');
  const connectingOverlay = document.getElementById('connecting-overlay');
  const screenShareVideo = document.getElementById('screen-share-video');
  const screenStrip = document.getElementById('screen-strip');

  const ctrlMic = document.getElementById('ctrl-mic');
  const ctrlCam = document.getElementById('ctrl-cam');
  const ctrlScreen = document.getElementById('ctrl-screen');
  const ctrlChat = document.getElementById('ctrl-chat');
  const ctrlParticipants = document.getElementById('ctrl-participants');
  const ctrlSettings = document.getElementById('ctrl-settings');
  const ctrlLeave = document.getElementById('ctrl-leave');
  const chatBadge = document.getElementById('chat-badge');

  const chatPanel = document.getElementById('chat-panel');
  const participantsPanel = document.getElementById('participants-panel');

  // ---------- Elementos: Modal de configurações ----------
  const settingsModal = document.getElementById('settings-modal');
  const settingsPreviewVideo = document.getElementById('settings-preview-video');
  const settingsCameraSelect = document.getElementById('settings-camera-select');
  const settingsMicSelect = document.getElementById('settings-mic-select');
  const settingsSpeakerSelect = document.getElementById('settings-speaker-select');
  const settingsSpeakerWrap = document.getElementById('settings-speaker-wrap');
  const micTestFill = document.getElementById('mic-test-fill');
  const btnCloseSettings = document.getElementById('btn-close-settings');

  lobbyRoomIdEl.textContent = roomId;

  // ---------- Estado ----------
  let localStream = null;      // câmera + mic
  let screenStream = null;     // stream de compartilhamento de tela
  let socket = null;
  let webrtc = null;
  let chat = null;
  let participants = null;
  let mySocketId = null;
  let myUserName = 'Convidado';
  let micEnabled = true;
  let camEnabled = true;
  let isSharingScreen = false;
  let sharingPeerId = null; // quem está compartilhando tela no momento (pode ser "local")
  let micLevelTester = null;
  let speakingLoop = null;
  let currentlySpeakingLocal = false;

  // peerId -> { videoEl, tileEl, stream }
  const remoteTiles = new Map();

  // ==========================================================================
  // LOBBY - obtenção de mídia local e seleção de dispositivos
  // ==========================================================================

  async function prefillAccountName() {
    try {
      const res = await fetch('/api/auth/me');
      const data = await res.json();
      if (data.user?.name && !lobbyUsername.value) {
        lobbyUsername.value = data.user.name;
        myUserName = data.user.name;
      }
    } catch {
      // Sem conexão com a API — segue com o valor padrão "Convidado"
    }
  }

  async function initLobbyMedia() {
    try {
      localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      lobbyVideo.srcObject = localStream;
      lobbyAvatarFallback.classList.add('hidden');
    } catch (err) {
      console.warn('Não foi possível acessar câmera/microfone:', err);
      lobbyAvatarFallback.classList.remove('hidden');
      showToast('Permita o acesso à câmera e ao microfone para entrar na chamada.');
    }
    await populateDeviceSelect(lobbyCameraSelect, 'videoinput');
    await populateDeviceSelect(lobbyMicSelect, 'audioinput');
  }

  lobbyToggleMic.addEventListener('click', () => {
    micEnabled = !micEnabled;
    setToggleBtnState(lobbyToggleMic, micEnabled, '🎤', '🔇');
    localStream?.getAudioTracks().forEach((t) => (t.enabled = micEnabled));
  });

  lobbyToggleCam.addEventListener('click', () => {
    camEnabled = !camEnabled;
    setToggleBtnState(lobbyToggleCam, camEnabled, '📷', '🚫');
    localStream?.getVideoTracks().forEach((t) => (t.enabled = camEnabled));
    lobbyAvatarFallback.classList.toggle('hidden', camEnabled);
  });

  async function switchLobbyDevice(kind, deviceId) {
    const constraints = kind === 'video'
      ? { video: { deviceId: { exact: deviceId } }, audio: lobbyMicSelect.value ? { deviceId: { exact: lobbyMicSelect.value } } : true }
      : { audio: { deviceId: { exact: deviceId } }, video: lobbyCameraSelect.value ? { deviceId: { exact: lobbyCameraSelect.value } } : true };
    try {
      const newStream = await navigator.mediaDevices.getUserMedia(constraints);
      localStream?.getTracks().forEach((t) => t.stop());
      localStream = newStream;
      lobbyVideo.srcObject = localStream;
      localStream.getAudioTracks().forEach((t) => (t.enabled = micEnabled));
      localStream.getVideoTracks().forEach((t) => (t.enabled = camEnabled));
    } catch (err) {
      showToast('Não foi possível trocar o dispositivo selecionado.');
    }
  }
  lobbyCameraSelect.addEventListener('change', () => switchLobbyDevice('video', lobbyCameraSelect.value));
  lobbyMicSelect.addEventListener('change', () => switchLobbyDevice('audio', lobbyMicSelect.value));

  function setToggleBtnState(btn, enabled, onIcon, offIcon) {
    btn.classList.toggle('active', enabled);
    btn.classList.toggle('off', !enabled);
    btn.textContent = enabled ? onIcon : offIcon;
  }

  lobbyJoinBtn.addEventListener('click', () => {
    myUserName = lobbyUsername.value.trim() || 'Convidado';
    enterCall();
  });

  // ==========================================================================
  // ENTRAR NA CHAMADA
  // ==========================================================================

  function enterCall() {
    lobbyView.classList.add('hidden');
    callView.classList.remove('hidden');
    callRoomName.textContent = `Sala ${roomId}`;
    connectingOverlay.classList.remove('hidden');

    socket = io();

    socket.on('connect_error', (err) => {
      connectingOverlay.classList.add('hidden');
      if (err?.message === 'unauthorized') {
        showToast('Sua sessão expirou. Faça login novamente.');
        setTimeout(() => { window.location.href = '/login.html'; }, 1200);
        return;
      }
      showToast('Não foi possível conectar. Verifique sua internet.');
    });

    socket.on('connect', () => {
      connectingOverlay.classList.add('hidden');
      mySocketId = socket.id;

      webrtc = new WebRTCManager({
        socket,
        onRemoteStream: handleRemoteStream,
        onPeerClosed: handlePeerClosed
      });
      webrtc.setLocalStream(localStream);

      chat = new ChatController({
        mySocketId,
        onUnread: () => chatBadge.classList.remove('hidden')
      });
      chat.onSend = (text) => socket.emit('chat-message', { text });

      participants = new ParticipantsController({ mySocketId });
      participants.upsert(mySocketId, { userName: myUserName, audio: micEnabled, video: camEnabled });

      // Cria meu próprio tile de vídeo na grade
      createLocalTile();

      attemptJoin();

      function attemptJoin(password) {
        socket.emit('join-room', { roomId, userName: myUserName, password }, (res) => {
          if (res?.requiresPassword) {
            const entered = prompt('Esta sala é protegida por senha:');
            if (entered === null) {
              showToast('Entrada cancelada');
              return;
            }
            attemptJoin(entered);
            return;
          }
          if (res?.error) {
            showToast(res.error);
            return;
          }
          // Conecta-se (como iniciador) a cada participante que já estava na sala
          (res.participants || []).forEach((p) => {
            participants.upsert(p.socketId, { userName: p.userName, audio: p.audio, video: p.video });
            createRemoteTilePlaceholder(p.socketId, p.userName);
            webrtc.connectToPeer(p.socketId);
          });
          updateGridLayout();
        });
      }
    });

    socket.on('user-joined', ({ socketId, userName }) => {
      participants.upsert(socketId, { userName, audio: true, video: true });
      createRemoteTilePlaceholder(socketId, userName);
      updateGridLayout();
      showToast(`${userName} entrou na sala`);
      // Não iniciamos a conexão aqui: quem entrou é responsável por nos enviar a oferta.
    });

    socket.on('user-left', ({ socketId }) => {
      const info = participants.participants.get(socketId);
      participants.remove(socketId);
      webrtc.removePeer(socketId);
      removeRemoteTile(socketId);
      updateGridLayout();
      if (info) showToast(`${info.userName} saiu da sala`);
      if (sharingPeerId === socketId) stopWatchingRemoteScreenShare();
    });

    socket.on('media-state', ({ socketId, audio, video }) => {
      participants.upsert(socketId, { audio, video });
      updateTileIndicators(socketId, { audio, video });
    });

    socket.on('speaking', ({ socketId, speaking }) => {
      participants.upsert(socketId, { speaking });
      const tile = remoteTiles.get(socketId);
      if (tile) tile.tileEl.classList.toggle('speaking', speaking);
    });

    socket.on('screen-share', ({ socketId, active }) => {
      if (active) {
        watchRemoteScreenShare(socketId);
      } else if (sharingPeerId === socketId) {
        stopWatchingRemoteScreenShare();
      }
    });

    socket.on('chat-message', (msg) => chat.addMessage(msg));

    startSpeakingDetection();
  }

  // ==========================================================================
  // GRADE DE VÍDEOS
  // ==========================================================================

  function createVideoTile(id, { isLocal = false, userName = 'Convidado' } = {}) {
    const tile = document.createElement('div');
    tile.className = 'video-tile fade-in';
    tile.dataset.peerId = id;

    const video = document.createElement('video');
    video.autoplay = true;
    video.playsInline = true;
    if (isLocal) { video.muted = true; video.classList.add('mirrored'); }

    const fallback = document.createElement('div');
    fallback.className = 'avatar-fallback';
    fallback.innerHTML = `<div class="circle">${(userName || '?').charAt(0).toUpperCase()}</div>`;

    const label = document.createElement('div');
    label.className = 'tile-label';
    label.innerHTML = `<span class="name-text">${escapeHtml(userName)}${isLocal ? ' (você)' : ''}</span><span class="mic-off-icon hidden">🔇</span>`;

    tile.appendChild(fallback);
    tile.appendChild(video);
    tile.appendChild(label);
    return { tile, video, fallback, label };
  }

  function createLocalTile() {
    const { tile, video, fallback } = createVideoTile(mySocketId, { isLocal: true, userName: myUserName });
    video.srcObject = localStream;
    fallback.classList.toggle('hidden', camEnabled);
    videoGrid.appendChild(tile);
    remoteTiles.set(mySocketId, { tileEl: tile, video, fallback, stream: localStream });
  }

  function createRemoteTilePlaceholder(peerId, userName) {
    if (remoteTiles.has(peerId)) return;
    const { tile, video, fallback } = createVideoTile(peerId, { userName });
    videoGrid.appendChild(tile);
    remoteTiles.set(peerId, { tileEl: tile, video, fallback, stream: null });
  }

  function handleRemoteStream(peerId, stream) {
    let entry = remoteTiles.get(peerId);
    if (!entry) {
      createRemoteTilePlaceholder(peerId, participants?.participants.get(peerId)?.userName || 'Convidado');
      entry = remoteTiles.get(peerId);
    }
    entry.video.srcObject = stream;
    entry.stream = stream;
    entry.fallback.classList.add('hidden');
  }

  function removeRemoteTile(peerId) {
    const entry = remoteTiles.get(peerId);
    if (entry) {
      entry.tileEl.remove();
      remoteTiles.delete(peerId);
    }
  }

  function handlePeerClosed(peerId) {
    removeRemoteTile(peerId);
    updateGridLayout();
  }

  function updateTileIndicators(peerId, { audio, video }) {
    const entry = remoteTiles.get(peerId);
    if (!entry) return;
    entry.tileEl.querySelector('.mic-off-icon').classList.toggle('hidden', audio !== false);
    entry.fallback.classList.toggle('hidden', video !== false && !!entry.stream);
  }

  function updateGridLayout() {
    const count = Math.max(1, remoteTiles.size);
    videoGrid.className = `video-grid count-${Math.min(count, 9)}`;
  }

  // (escapeHtml é definido em participants.js, carregado antes deste arquivo)

  // ==========================================================================
  // MICROFONE / CÂMERA (dentro da chamada)
  // ==========================================================================

  ctrlMic.addEventListener('click', () => {
    micEnabled = !micEnabled;
    localStream?.getAudioTracks().forEach((t) => (t.enabled = micEnabled));
    setToggleBtnState(ctrlMic, micEnabled, '🎤', '🔇');
    socket?.emit('media-state', { audio: micEnabled, video: camEnabled });
    participants?.upsert(mySocketId, { audio: micEnabled });
  });

  ctrlCam.addEventListener('click', () => {
    camEnabled = !camEnabled;
    localStream?.getVideoTracks().forEach((t) => (t.enabled = camEnabled));
    setToggleBtnState(ctrlCam, camEnabled, '📷', '🚫');
    const myTile = remoteTiles.get(mySocketId);
    myTile?.fallback.classList.toggle('hidden', camEnabled);
    socket?.emit('media-state', { audio: micEnabled, video: camEnabled });
    participants?.upsert(mySocketId, { video: camEnabled });
  });

  // ==========================================================================
  // COMPARTILHAMENTO DE TELA
  // ==========================================================================

  ctrlScreen.addEventListener('click', () => {
    if (isSharingScreen) stopScreenShare();
    else startScreenShare();
  });

  async function startScreenShare() {
    try {
      screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
    } catch (err) {
      // Usuário cancelou a seleção de tela/janela/aba - não é um erro real
      return;
    }
    const screenTrack = screenStream.getVideoTracks()[0];

    // Substitui a track de vídeo enviada a todos os peers, sem precisar renegociar
    await webrtc.replaceVideoTrackForAll(screenTrack);

    isSharingScreen = true;
    sharingPeerId = mySocketId;
    ctrlScreen.classList.add('active');
    socket.emit('screen-share', { active: true });

    // Mostra minha própria tela compartilhada na área principal
    enterScreenShareView(screenStream, myUserName, true);

    // Se o usuário parar o compartilhamento pelos controles nativos do navegador
    screenTrack.addEventListener('ended', () => stopScreenShare());
  }

  async function stopScreenShare() {
    if (!isSharingScreen) return;
    screenStream?.getTracks().forEach((t) => t.stop());
    screenStream = null;
    isSharingScreen = false;
    sharingPeerId = null;
    ctrlScreen.classList.remove('active');

    // Volta a enviar a track da câmera
    const camTrack = localStream.getVideoTracks()[0];
    if (camTrack) await webrtc.replaceVideoTrackForAll(camTrack);

    socket.emit('screen-share', { active: false });
    exitScreenShareView();
  }

  function watchRemoteScreenShare(peerId) {
    sharingPeerId = peerId;
    const entry = remoteTiles.get(peerId);
    const userName = participants?.participants.get(peerId)?.userName || 'Participante';
    if (entry?.stream) {
      enterScreenShareView(entry.stream, userName, false);
    } else {
      // O stream de vídeo (agora contendo a tela) chegará via ontrack normalmente;
      // assim que handleRemoteStream atualizar, refletimos na visão de tela cheia.
      enterScreenShareView(null, userName, false);
      const check = setInterval(() => {
        const e = remoteTiles.get(peerId);
        if (e?.stream) {
          screenShareVideo.srcObject = e.stream;
          clearInterval(check);
        }
      }, 300);
    }
  }

  function stopWatchingRemoteScreenShare() {
    sharingPeerId = null;
    exitScreenShareView();
  }

  function enterScreenShareView(stream, presenterName, isLocal) {
    videoStage.classList.add('screen-mode');
    if (stream) screenShareVideo.srcObject = stream;
    showToast(isLocal ? 'Você está compartilhando sua tela' : `${presenterName} está compartilhando a tela`);
  }

  function exitScreenShareView() {
    videoStage.classList.remove('screen-mode');
    screenShareVideo.srcObject = null;
  }

  // ==========================================================================
  // DETECÇÃO DE "QUEM ESTÁ FALANDO" (Web Audio API)
  // ==========================================================================

  function startSpeakingDetection() {
    if (!localStream || localStream.getAudioTracks().length === 0) return;
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 512;
    const source = audioCtx.createMediaStreamSource(localStream);
    source.connect(analyser);
    const data = new Uint8Array(analyser.frequencyBinCount);

    const THRESHOLD = 18;
    speakingLoop = setInterval(() => {
      analyser.getByteFrequencyData(data);
      const avg = data.reduce((a, b) => a + b, 0) / data.length;
      const speakingNow = micEnabled && avg > THRESHOLD;
      if (speakingNow !== currentlySpeakingLocal) {
        currentlySpeakingLocal = speakingNow;
        socket?.emit('speaking', { speaking: speakingNow });
        const myTile = remoteTiles.get(mySocketId);
        myTile?.tileEl.classList.toggle('speaking', speakingNow);
        participants?.upsert(mySocketId, { speaking: speakingNow });
      }
    }, 250);
  }

  // ==========================================================================
  // PAINÉIS LATERAIS (chat / participantes)
  // ==========================================================================

  function togglePanel(panelEl, otherPanelEl) {
    const willOpen = panelEl.classList.contains('hidden-panel');
    otherPanelEl.classList.add('hidden-panel');
    panelEl.classList.toggle('hidden-panel', !willOpen);
    if (panelEl === chatPanel && willOpen) chatBadge.classList.add('hidden');
  }

  ctrlChat.addEventListener('click', () => togglePanel(chatPanel, participantsPanel));
  ctrlParticipants.addEventListener('click', () => togglePanel(participantsPanel, chatPanel));

  document.querySelectorAll('[data-close]').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.getElementById(btn.dataset.close).classList.add('hidden-panel');
    });
  });

  // ==========================================================================
  // CONFIGURAÇÕES
  // ==========================================================================

  ctrlSettings.addEventListener('click', openSettingsModal);
  btnCloseSettings.addEventListener('click', closeSettingsModal);

  document.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach((p) => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
    });
  });

  async function openSettingsModal() {
    settingsModal.classList.remove('hidden');
    settingsPreviewVideo.srcObject = localStream;

    await populateDeviceSelect(settingsCameraSelect, 'videoinput');
    await populateDeviceSelect(settingsMicSelect, 'audioinput');

    // Nem todos os navegadores suportam seleção de alto-falante (ex: Firefox/Safari)
    const speakers = await populateDeviceSelect(settingsSpeakerSelect, 'audiooutput');
    settingsSpeakerWrap.classList.toggle('hidden', speakers.length === 0);

    if (localStream) {
      micLevelTester?.stop();
      micLevelTester = new MicLevelTester(localStream, (level) => {
        micTestFill.style.width = `${level}%`;
      });
      micLevelTester.start();
    }
  }

  function closeSettingsModal() {
    settingsModal.classList.add('hidden');
    micLevelTester?.stop();
    micLevelTester = null;
  }

  async function applySettingsDevice(kind, deviceId) {
    const constraints = kind === 'video'
      ? { video: { deviceId: { exact: deviceId } }, audio: { deviceId: settingsMicSelect.value ? { exact: settingsMicSelect.value } : undefined } }
      : { audio: { deviceId: { exact: deviceId } }, video: { deviceId: settingsCameraSelect.value ? { exact: settingsCameraSelect.value } : undefined } };

    try {
      const newStream = await navigator.mediaDevices.getUserMedia(constraints);
      const newVideoTrack = newStream.getVideoTracks()[0];
      const newAudioTrack = newStream.getAudioTracks()[0];

      // Substitui as tracks em todas as conexões ativas sem precisar renegociar
      if (newVideoTrack && !isSharingScreen) await webrtc.replaceVideoTrackForAll(newVideoTrack);

      const oldVideoTrack = localStream.getVideoTracks()[0];
      const oldAudioTrack = localStream.getAudioTracks()[0];
      if (oldVideoTrack) { localStream.removeTrack(oldVideoTrack); oldVideoTrack.stop(); }
      if (oldAudioTrack) { localStream.removeTrack(oldAudioTrack); oldAudioTrack.stop(); }
      if (newVideoTrack) { localStream.addTrack(newVideoTrack); newVideoTrack.enabled = camEnabled; }
      if (newAudioTrack) { localStream.addTrack(newAudioTrack); newAudioTrack.enabled = micEnabled; }

      webrtc.setLocalStream(localStream);
      settingsPreviewVideo.srcObject = localStream;
      const myTile = remoteTiles.get(mySocketId);
      if (myTile) myTile.video.srcObject = localStream;
    } catch (err) {
      showToast('Não foi possível trocar o dispositivo.');
    }
  }
  settingsCameraSelect.addEventListener('change', () => applySettingsDevice('video', settingsCameraSelect.value));
  settingsMicSelect.addEventListener('change', () => applySettingsDevice('audio', settingsMicSelect.value));

  settingsSpeakerSelect.addEventListener('change', async () => {
    const speakerId = settingsSpeakerSelect.value;
    // setSinkId é suportado apenas em alguns navegadores (Chrome/Edge)
    remoteTiles.forEach(({ video }) => {
      if (typeof video.setSinkId === 'function') video.setSinkId(speakerId).catch(() => {});
    });
  });

  // ==========================================================================
  // SAIR DA CHAMADA
  // ==========================================================================

  ctrlLeave.addEventListener('click', () => {
    socket?.emit('leave-room');
    webrtc?.closeAll();
    localStream?.getTracks().forEach((t) => t.stop());
    screenStream?.getTracks().forEach((t) => t.stop());
    if (speakingLoop) clearInterval(speakingLoop);
    window.location.href = '/';
  });

  window.addEventListener('beforeunload', () => {
    socket?.emit('leave-room');
    localStream?.getTracks().forEach((t) => t.stop());
    screenStream?.getTracks().forEach((t) => t.stop());
  });

  // ==========================================================================
  // INICIALIZAÇÃO
  // ==========================================================================

  prefillAccountName();
  initLobbyMedia();
})();
