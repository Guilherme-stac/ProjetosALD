// server.js
// Servidor principal: serve o frontend estático, autentica usuários (sessão)
// e atua como servidor de sinalização WebRTC via Socket.IO (troca de
// offers/answers/ICE candidates entre participantes).
// A mídia (áudio/vídeo/tela) NUNCA passa por este servidor - ela viaja diretamente
// entre os navegadores dos participantes via WebRTC (peer-to-peer).

const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');
const { RoomManager } = require('./src/roomManager');
const { SocketRateLimiter } = require('./src/socketRateLimiter');
const userStore = require('./src/userStore');

// Em produção, defina ALLOWED_ORIGIN no ambiente (ex: https://meusite.com).
// Sem isso, o CORS fica restrito ao próprio host — nunca '*'.
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || false;
const IS_PROD = process.env.NODE_ENV === 'production';

// Segredo de sessão: defina SESSION_SECRET em produção para que as sessões
// sobrevivam a reinícios do servidor. Sem ele, um segredo aleatório é gerado
// a cada boot (todas as sessões anteriores são invalidadas ao reiniciar).
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
if (!process.env.SESSION_SECRET) {
  console.warn('⚠️  SESSION_SECRET não definido — usando um segredo temporário gerado neste boot.');
}

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: ALLOWED_ORIGIN || false }
});

const PORT = process.env.PORT || 3000;
const rooms = new RoomManager();
const limiter = new SocketRateLimiter();

if (IS_PROD) app.set('trust proxy', 1);

// --- Segurança HTTP ---
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'", 'ws:', 'wss:'],
      mediaSrc: ["'self'", 'blob:'],
    }
  }
}));

// Limite de tamanho do corpo das requisições (evita payload gigante como vetor de DoS)
app.use(express.json({ limit: '10kb' }));

// --- Sessão (compartilhada entre Express e Socket.IO) ---
const sessionMiddleware = session({
  secret: SESSION_SECRET,
  name: 'nexmeet.sid',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: IS_PROD,
    maxAge: 1000 * 60 * 60 * 24 * 7 // 7 dias
  }
});
app.use(sessionMiddleware);

// Rate limit geral para toda a API REST
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 60,
  standardHeaders: true,
  legacyHeaders: false
});
app.use('/api/', apiLimiter);

// Login/registro são alvo comum de força bruta — limite mais rígido
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Muitas tentativas. Aguarde alguns minutos.' }
});

// Criação de sala é mais sensível (spam de salas) — limite mais rígido
const createRoomLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false
});

// Middleware: exige usuário autenticado. Em rotas de página, redireciona
// para o login; em rotas de API, responde 401 em JSON.
function requireAuth(req, res, next) {
  if (req.session && req.session.user) return next();
  if (req.path.startsWith('/api/')) {
    return res.status(401).json({ error: 'Não autenticado' });
  }
  const redirectTo = encodeURIComponent(req.originalUrl || '/');
  return res.redirect(`/login.html?redirect=${redirectTo}`);
}

// --- API de autenticação ---

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

app.post('/api/auth/register', authLimiter, async (req, res) => {
  try {
    const { name, email, password } = req.body || {};
    const safeName = String(name || '').trim();
    const safeEmail = userStore.normalizeEmail(email);

    if (!safeName || safeName.length < 2) {
      return res.status(400).json({ error: 'Informe um nome com pelo menos 2 caracteres.' });
    }
    if (!EMAIL_RE.test(safeEmail)) {
      return res.status(400).json({ error: 'Informe um e-mail válido.' });
    }
    if (!password || String(password).length < 6) {
      return res.status(400).json({ error: 'A senha precisa ter pelo menos 6 caracteres.' });
    }
    if (userStore.findByEmail(safeEmail)) {
      return res.status(409).json({ error: 'Já existe uma conta com esse e-mail.' });
    }

    const passwordHash = await bcrypt.hash(String(password), 12);
    const user = userStore.createUser({ name: safeName, email: safeEmail, passwordHash });

    req.session.regenerate((err) => {
      if (err) return res.status(500).json({ error: 'Erro ao criar sessão.' });
      req.session.user = userStore.toPublicUser(user);
      res.json({ user: req.session.user });
    });
  } catch (err) {
    console.error('[auth] Erro no registro:', err);
    res.status(500).json({ error: 'Erro interno ao criar conta.' });
  }
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
  try {
    const { email, password } = req.body || {};
    const safeEmail = userStore.normalizeEmail(email);
    const user = userStore.findByEmail(safeEmail);

    // Mesma mensagem de erro para e-mail inexistente ou senha errada,
    // para não revelar quais e-mails estão cadastrados.
    const genericError = { error: 'E-mail ou senha incorretos.' };
    if (!user) return res.status(401).json(genericError);

    const ok = await bcrypt.compare(String(password || ''), user.passwordHash);
    if (!ok) return res.status(401).json(genericError);

    req.session.regenerate((err) => {
      if (err) return res.status(500).json({ error: 'Erro ao criar sessão.' });
      req.session.user = userStore.toPublicUser(user);
      res.json({ user: req.session.user });
    });
  } catch (err) {
    console.error('[auth] Erro no login:', err);
    res.status(500).json({ error: 'Erro interno ao entrar.' });
  }
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('nexmeet.sid');
    res.json({ ok: true });
  });
});

app.get('/api/auth/me', (req, res) => {
  res.json({ user: req.session?.user || null });
});

// --- Páginas protegidas ---
// (o estático de /public é servido mais abaixo, sem servir index.html
// automaticamente, para que a checagem de login abaixo sempre rode primeiro)

app.get(['/', '/index.html'], requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Permite acessar /room/<id> diretamente (link compartilhável)
app.get('/room/:id', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'room.html'));
});

// Se já estiver logado, não faz sentido ver a tela de login/registro de novo
app.get(['/login.html', '/register.html'], (req, res, next) => {
  if (req.session?.user) return res.redirect('/');
  next();
});

app.use(express.static(path.join(__dirname, 'public'), { index: false }));

// --- API REST auxiliar de salas (exige login) ---

// Cria uma sala nova e retorna um ID único e difícil de adivinhar.
// Opcionalmente aceita { password } no corpo para trancar a sala.
app.post('/api/rooms', requireAuth, createRoomLimiter, (req, res) => {
  const { password } = req.body || {};
  const passwordHash = password
    ? crypto.createHash('sha256').update(String(password)).digest('hex')
    : null;
  const roomId = rooms.createRoom(passwordHash);
  res.json({ roomId, locked: !!passwordHash });
});

// Verifica se uma sala existe e se está trancada (usado antes de entrar)
app.get('/api/rooms/:id', requireAuth, (req, res) => {
  const exists = rooms.roomExists(req.params.id);
  res.json({ exists, locked: exists && rooms.isLocked(req.params.id) });
});

// --- Sinalização WebRTC via Socket.IO ---

// Compartilha a sessão HTTP com as conexões Socket.IO, para que só usuários
// autenticados possam abrir um socket de sinalização.
io.use((socket, next) => {
  sessionMiddleware(socket.request, {}, next);
});

io.use((socket, next) => {
  const session = socket.request.session;
  if (!session || !session.user) {
    return next(new Error('unauthorized'));
  }
  socket.data.accountUser = session.user;
  next();
});

io.on('connection', (socket) => {
  console.log(`[socket] conectado: ${socket.id} (${socket.data.accountUser?.email || '?'})`);

  // Um usuário entra em uma sala
  socket.on('join-room', ({ roomId, userName, password }, callback) => {
    if (!limiter.check(socket.id, 'join-room', 5, 10_000)) {
      return callback?.({ error: 'Muitas tentativas. Aguarde um instante.' });
    }

    if (!roomId || typeof roomId !== 'string' || roomId.length > 64) {
      return callback?.({ error: 'ID de sala inválido' });
    }

    if (!rooms.roomExists(roomId)) {
      return callback?.({ error: 'Sala não encontrada' });
    }

    if (rooms.isLocked(roomId)) {
      const passwordHash = password
        ? crypto.createHash('sha256').update(String(password)).digest('hex')
        : null;
      if (!rooms.checkPassword(roomId, passwordHash)) {
        return callback?.({ error: 'Senha incorreta', requiresPassword: true });
      }
    }

    const fallbackName = socket.data.accountUser?.name || 'Convidado';
    const safeName = sanitizeText(userName || fallbackName).slice(0, 40) || fallbackName;

    socket.join(roomId);
    socket.data.roomId = roomId;
    socket.data.userName = safeName;

    // Envia ao novo participante a lista de quem já está na sala,
    // para que ele inicie as conexões WebRTC com cada um deles.
    const existingParticipants = rooms.getParticipants(roomId);

    rooms.addParticipant(roomId, socket.id, { userName: safeName, audio: true, video: true });

    callback?.({ participants: existingParticipants, yourId: socket.id });

    // Avisa aos participantes já presentes que alguém novo entrou
    socket.to(roomId).emit('user-joined', {
      socketId: socket.id,
      userName: safeName
    });

    console.log(`[room ${roomId}] ${safeName} (${socket.id}) entrou. Total: ${rooms.getParticipantCount(roomId)}`);
  });

  // Relay de sinalização WebRTC (SDP offers/answers e ICE candidates).
  // O servidor apenas repassa - não interpreta o conteúdo.
  // Importante: só repassa para um socket que esteja NA MESMA SALA de quem envia.
  // Sem essa checagem, qualquer cliente conectado podia mandar signal para
  // qualquer socketId do servidor inteiro (sondagem/abuso entre salas).
  socket.on('signal', ({ to, signal }) => {
    if (!limiter.check(socket.id, 'signal', 60, 10_000)) return;
    if (!to || !signal) return;

    const roomId = socket.data.roomId;
    if (!roomId) return;

    const targetSocket = io.sockets.sockets.get(to);
    if (!targetSocket || targetSocket.data.roomId !== roomId) return;

    io.to(to).emit('signal', { from: socket.id, signal });
  });

  // Estado de microfone/câmera do participante (para exibir ícones aos outros)
  socket.on('media-state', ({ audio, video }) => {
    if (!limiter.check(socket.id, 'media-state', 20, 10_000)) return;
    const roomId = socket.data.roomId;
    if (!roomId) return;
    rooms.updateParticipant(roomId, socket.id, { audio: !!audio, video: !!video });
    socket.to(roomId).emit('media-state', { socketId: socket.id, audio: !!audio, video: !!video });
  });

  // Notifica início/fim de compartilhamento de tela
  socket.on('screen-share', ({ active }) => {
    if (!limiter.check(socket.id, 'screen-share', 20, 10_000)) return;
    const roomId = socket.data.roomId;
    if (!roomId) return;
    socket.to(roomId).emit('screen-share', { socketId: socket.id, active: !!active });
  });

  // Indicador de "quem está falando" (calculado no cliente via Web Audio API)
  socket.on('speaking', ({ speaking }) => {
    if (!limiter.check(socket.id, 'speaking', 30, 5_000)) return;
    const roomId = socket.data.roomId;
    if (!roomId) return;
    socket.to(roomId).emit('speaking', { socketId: socket.id, speaking: !!speaking });
  });

  // Mensagens de chat em tempo real
  socket.on('chat-message', ({ text }) => {
    if (!limiter.check(socket.id, 'chat-message', 10, 10_000)) return;
    const roomId = socket.data.roomId;
    if (!roomId || !text) return;

    const clean = sanitizeText(String(text)).slice(0, 1000).trim();
    if (!clean) return;

    const message = {
      socketId: socket.id,
      userName: socket.data.userName || 'Convidado',
      text: clean,
      timestamp: Date.now()
    };
    io.to(roomId).emit('chat-message', message);
  });

  socket.on('leave-room', () => leaveCurrentRoom(socket));
  socket.on('disconnect', () => {
    leaveCurrentRoom(socket);
    limiter.clear(socket.id);
    console.log(`[socket] desconectado: ${socket.id}`);
  });

  function leaveCurrentRoom(socket) {
    const roomId = socket.data.roomId;
    if (!roomId) return;
    rooms.removeParticipant(roomId, socket.id);
    socket.to(roomId).emit('user-left', { socketId: socket.id });
    socket.leave(roomId);
    socket.data.roomId = null;
  }
});

// Sanitização simples para mitigar XSS em nomes/mensagens
// (o frontend também usa textContent/innerText em vez de innerHTML como segunda camada)
function sanitizeText(str) {
  return String(str)
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

server.listen(PORT, () => {
  console.log(`✅ Servidor rodando em http://localhost:${PORT}`);
});
